<?php

class Doctor
{
	public static function insert($doctor_id, $doctor_name)
	{
		$doctor_id = mysql_real_escape_string($doctor_id);
		$doctor_name = mysql_real_escape_string($doctor_name);

		if (empty($doctor_id))
		{
			$doctor_id = 'NULL';
		}
		else
		{
			$doctor_id = '"' . $doctor_id . '"';
		}

		$sql = 'INSERT INTO `sp_doctor` (`doctor_id`, `doctor_name`) VALUES (' . $doctor_id . ',"' . $doctor_name . '")';

		mysql_query($sql) or die(mysql_error());
	}

	public static function update($doctor_id, $doctor_name)
	{
		$doctor_id = mysql_real_escape_string($doctor_id);
		$doctor_name = mysql_real_escape_string($doctor_name);

		if (empty($doctor_id))
		{
			$doctor_id = 'NULL';
		}
		else
		{
			$doctor_id = '"' . $doctor_id . '"';
		}

		$sql = 'UPDATE `sp_doctor` set `doctor_name`="' . $doctor_name . '" WHERE `doctor_id`=' . $doctor_id;

		mysql_query($sql) or die(mysql_error());
	}

	public static function delete($doctor_id)
	{
		$doctor_id = mysql_real_escape_string($doctor_id);
		$sql = 'DELETE FROM `sp_doctor` WHERE `doctor_id`=' . $doctor_id;

		mysql_query($sql) or die(mysql_error());
	}

	public static function count()
	{
		$sql = 'SELECT count(*) as `count` FROM `sp_doctor`';
		$rsa = mysql_query($sql);
		$row = mysql_fetch_assoc($rsa);
		return $row['count'];
	}

	public static function all($key = null, $page = null, $per_page = null)
	{
		if ($page != null && $per_page != null)
		{
			$count = Doctor::count();
			$offset = $per_page * ($page - 1);
			$limit = $per_page;

			$sql = 'SELECT * FROM `sp_doctor` LIMIT ' . $limit . ' OFFSET ' . $offset;
		}
		else
		{
			$sql = 'SELECT * FROM `sp_doctor`';
		}

		$rsa = mysql_query($sql);

		$arr = [];

		while ($row = mysql_fetch_assoc($rsa))
		{
			if ($key == null)
			{
				$arr[] = $row;
			}
			else
			{
				if (array_key_exists($key, $row))
				{
					$arr[$row[$key]] = $row;
				}
				else
				{
					$arr[] = $row;
				}
			}
		}

		return $arr;
	}


	public static function by_id($doctor_id)
	{
		$doctor_id = mysql_real_escape_string($doctor_id);
		$sql = 'SELECT * FROM `sp_doctor` WHERE `doctor_id`="' . $doctor_id . '"';
		$rsa = mysql_query($sql);

		while ($row = mysql_fetch_assoc($rsa))
		{
			return $row;
		}

		return false;
	}
}