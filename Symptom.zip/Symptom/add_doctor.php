<?php

include "db_connect.php";
include "functions.php";

db_connect();

$form_row = ['doctor_id' => '', 'doctor_name' => ''];

#######################################################################################################
#UPDATE
#######################################################################################################


if ( array_key_exists('action', $_GET) && $_GET['action'] == 'edit')
{
	if (!empty($_POST))
	{
		Doctor::update($_GET['doctor_id'], $_POST['doctor_name']);
		header('Location: http://localhost/xampp/Symptom/add_doctor.php');
	}

	$form_row = Doctor::by_id($_GET['doctor_id']);
}

#######################################################################################################
#DELETE
#######################################################################################################


if ( array_key_exists('action', $_GET) && $_GET['action'] == 'delete')
{
	Doctor::delete($_GET['doctor_id']);
	header('Location: http://localhost/xampp/Symptom/add_doctor.php');
}

#######################################################################################################
#INSERTION
#######################################################################################################


if (!empty($_POST) && !array_key_exists('action', $_GET))
{
	Doctor::insert($_POST['doctor_id'], $_POST['doctor_name']);
	header('Location: http://localhost/xampp/Symptom/add_doctor.php');
}

?><!DOCTYPE html>
<html>
<head>
	<title>Add Doctor</title>
<style>

body {
	     background-color: #C0C0C0;
	    text-align: center;

     }

</style>

</head>


<body>

<form action="" method="post" >
<br />
<table align="center">
	<tr>
		<td>Doctor_Id</td>
		<td><input type="text" name="doctor_id" value="<?php echo $form_row['doctor_id']; ?>" /></td>
	</tr>

	<tr>
		<td>Doctor_Name</td>
		<td><input type="text" name="doctor_name" value="<?php echo $form_row['doctor_name']; ?>" /></td>
	</tr>

	<tr>
		<td></td>
		<td><input type="submit" value="<?php echo empty($form_row['doctor_id']) ? 'Add':'Update'; ?>" /></td>
	</tr>

</table>

<br /> <br />
<table border = "1" width="500" align = "center" >
	<tr>
		<th>Doctor_Id</td>
		<th>Doctor_Name</td>
		<th>Actions</td>
	</tr>
<?php

$is_page = 0; // No page id was sent in url params

 if (isset($_GET['page']))
{
 	$page = $_GET['page'];
 	$is_page = 1; // Page is set
}
else
{
	$page = 1;
}


foreach (Doctor::all(null, $page, 5) as $doctor)
{
	echo '	<tr>' . "\r\n";
	echo '		<td>' . $doctor['doctor_id'] . '</td>' . "\r\n";
	echo '		<td>' . $doctor['doctor_name'] . '</td>' . "\r\n";
	echo '		<td><a href="?action=edit&doctor_id=' . $doctor['doctor_id'] .  '"  >  Edit</a> <a href="?action=delete&id=' . $doctor['doctor_id'] . '">Delete</a></td>' . "\r\n";
	echo '	</tr>' . "\r\n";

}
?>
</table>

<?php

$count = Doctor::count();
$pages = ceil($count / 5);

for ($page = 1; $page<=$pages; $page++)
{
	echo '<a href="?page=' . $page . '">' . $page . '</a> | ';
}


?>


</body>
</html>
