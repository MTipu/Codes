<?php
require_once "config.php";

@mysql_connect($config["db"]["server"], $config["db"]["user"], $config["db"]["password"]) or die(mysql_error());
mysql_select_db($config["db"]["database"]) or die(mysql_error());

session_start();

	if (!empty($_POST))
	{
		$username = mysql_real_escape_string($_POST['username']);
		$password = mysql_real_escape_string($_POST['password']);

		if ($username == "admin" && $password == "admin")
		{
			$_SESSION['user'] = "admin";
			header("Location: " . $config["project"]["url"]);
		}
	}


?><!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<form action="" method="post" > <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>
<table align="center" width="500">
	<tr>
		<th>User Name</th>
		<td><input type="text" name="username" value="" /></td>
	</tr>
	<tr>
		<th>Password</th>
		<td><input type="password" name="password" value="" /></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" value="Login" /></td>
	</tr>
</table>
</form>

</body>
</html>