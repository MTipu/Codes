<?php  

require_once "config.php";


@mysql_connect($config["db"]["server"], $config["db"]["user"], $config["db"]["password"]) or die(mysql_error());
mysql_select_db($config["db"]["database"]) or die(mysql_error());

#######################################################################################################################################
#For ALL Diseases
#######################################################################################################################################

if(empty($_GET['id']))
{
	$sql = 'SELECT * FROM `disease`';

	$rsa = mysql_query($sql);

	while($row = mysql_fetch_assoc($rsa))
	{
		echo '<a href="?id=' . $row['id'] . '">' . $row['name'] . '</a> <br> <br> ' ;
	}
}
else
{
	$id = mysql_real_escape_string($_GET['id']);
	$sql = 'SELECT * FROM `disease` WHERE `id`= ' . $id;

	$rsa = mysql_query($sql);
	$row = mysql_fetch_assoc($rsa);

	echo '<h1>' . $row['name'] . '</h1>';

	$sql = 'SELECT `category`.* FROM `disease_category`, `category` WHERE `disease_category`.`category_id`=`category`.`id` and `disease_id`=' . $id;
	$rsa = mysql_query($sql);

	echo '<h1>Categories</h1>';

	while($row = mysql_fetch_assoc($rsa))
	{
		echo '<li>' . $row['name'] . '</li>';
	}


	$sql = 'SELECT `symptom`.* FROM `symptom_disease`, `symptom` WHERE `symptom_disease`.`symptom_id`=`symptom`.`id` and `disease_id`=' . $id;
	$rsa = mysql_query($sql);

	echo '<h1>Symptoms</h1>';

	while($row = mysql_fetch_assoc($rsa))
	{
		echo '<li>' . $row['name'] . '</li>';
	}

	$sql = 'SELECT `medicine`.* FROM `disease_medicine`, `medicine` WHERE `disease_medicine`.`medicine_id`=`medicine`.`id` and `disease_id`=' . $id;
	$rsa = mysql_query($sql);

	echo '<h1>Medicines</h1>';

	while($row = mysql_fetch_assoc($rsa))
	{
		echo '<li>' . $row['name'] . '</li>';
	}

	$sql = 'SELECT `doctor`.* FROM `disease_category`,`doctor_category`, `doctor` WHERE `disease_category`.`category_id` = `doctor_category`.`category_id` AND `doctor_category`.`doctor_id` = `doctor`.`id` AND `disease_id`=' . $id;
	$rsa = mysql_query($sql);
	echo '<h1>Doctor</h1>';

	echo mysql_error();

	while($row = mysql_fetch_array($rsa))
	{
		echo '<li><a href="display_doctor.php?id=' . $row['id'] . '">' . $row['name'] . '</a></li>';
	}

}
