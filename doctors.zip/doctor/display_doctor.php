<?php  

require_once "config.php";


@mysql_connect($config["db"]["server"], $config["db"]["user"], $config["db"]["password"]) or die(mysql_error());
mysql_select_db($config["db"]["database"]) or die(mysql_error());

#######################################################################################################################################
#For ALL Doctors
#######################################################################################################################################

if(empty($_GET['id']))
{
	$sql = 'SELECT * FROM `doctor`';
	$rsa = mysql_query($sql);

	while($row = mysql_fetch_assoc($rsa))
	{
		echo '<a href="?id=' . $row['id'] . '">' . $row['name'] . '</a> <br> <br>';
	}
}
else
{
	$id = mysql_real_escape_string($_GET['id']);
	$sql = 'SELECT * FROM `doctor` WHERE `id`=' . $id;
	
	$rsa = mysql_query($sql);
	$row  =mysql_fetch_assoc($rsa);

	echo '<h1>' . $row['name'] . '</h1>';

	$sql = 'SELECT 	`category`.* FROM `doctor_category`, `category` WHERE `doctor_category`.`category_id` = `category`.`id` AND `doctor_id`=' . $id;
	$rsa = mysql_query($sql);

	echo '<h1>Doctor Categories</h1>';

	while($row = mysql_fetch_assoc($rsa))
	{
		echo '<li>' . $row['name'] . '</li>';
	}

	$sql = 'SELECT `zone`.*, `place_type`.`name` as `placetype` FROM `doctor_zone`, `place_type`, `zone` WHERE 	`doctor_zone`.`zone_id` = `zone`.`id` AND `doctor_zone`.`place_type_id` = `place_type`.`id` AND `doctor_id`=' . $id;
	$rsa = mysql_query($sql);

	echo '<h1>Doctor Zone</h1>';

	while($row = mysql_fetch_assoc($rsa))
	{
		echo '<li>' . $row['name'] . ":::" . $row['placetype']. '</li>';
	}
}

