<?php

$config = [
			"db" => [
						"server" => "localhost",
						"database" => "project",
						"user" => "root",
						"password" => "123456"
					],
			"project" => [
						"url" => "http://localhost/doctor/"
			]
		];


function check_login()
{
	global $config;

	session_start();

	if (empty($_SESSION['user']))
	{
		header("Location: " . $config["project"]["url"] . "login.php");
	}
}