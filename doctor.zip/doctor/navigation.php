
<ul class="menu">
	<li><a href="<?php echo $config["project"]["url"]; ?>bodypart_diseases.php">Bodypart Diseases</a></li>
	<li><a href="<?php echo $config["project"]["url"]; ?>bodyparts.php">Bodyparts</a></li>
	<li><a href="<?php echo $config["project"]["url"]; ?>category.php">Category</a></li>
	<li><a href="<?php echo $config["project"]["url"]; ?>disease.php">Disease</a></li>
	<li><a href="<?php echo $config["project"]["url"]; ?>disease_category.php">Disease Category</a></li>
	<li><a href="<?php echo $config["project"]["url"]; ?>disease_medicine.php">Disease Medicine</a></li>
	<li><a href="<?php echo $config["project"]["url"]; ?>doctor.php">Doctor</a></li>
	<li><a href="<?php echo $config["project"]["url"]; ?>doctor_category.php">Doctor Category</a></li>
	<li><a href="<?php echo $config["project"]["url"]; ?>doctor_zone.php">Doctor Zone</a></li>
	<li><a href="<?php echo $config["project"]["url"]; ?>medicine.php">Medicine</a></li>
	<li><a href="<?php echo $config["project"]["url"]; ?>place_type.php">Place Type</a></li>
	<li><a href="<?php echo $config["project"]["url"]; ?>symptom.php">Symptom</a></li>
	<li><a href="<?php echo $config["project"]["url"]; ?>symptom_disease.php">Symptom Disease</a></li>
	<li><a href="<?php echo $config["project"]["url"]; ?>zone.php">Zone</a></li>
</ul>
