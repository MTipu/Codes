<?php

require_once "config.php";

check_login();


@mysql_connect($config["db"]["server"], $config["db"]["user"], $config["db"]["password"]) or die(mysql_error());
mysql_select_db($config["db"]["database"]) or die(mysql_error());

$form_row = [
	'id' => '',
	'address' => '',
	'doctor_id' => '',
	'place_type_id' => '',
	'zone_id' => '',
];

################################################################################
# INSERT
################################################################################
if (!empty($_POST) && !array_key_exists('action', $_GET))
{
	$id = mysql_real_escape_string($_POST["id"]);
	$address = mysql_real_escape_string($_POST["address"]);
	$doctor_id = mysql_real_escape_string($_POST["doctor_id"]);
	$place_type_id = mysql_real_escape_string($_POST["place_type_id"]);
	$zone_id = mysql_real_escape_string($_POST["zone_id"]);
	
	if (empty($id))
	{
		$id = "NULL";
	}
	else
	{
		$id = '"' . $id . '"';
	}
	
	$sql = "INSERT INTO `doctor_zone` VALUES (" . $id . ", '" . $address . "', '" . $doctor_id . "', '" . $place_type_id . "', '" . $zone_id . "')";
	mysql_query($sql) or die(mysql_error());
}
################################################################################

################################################################################
// Update
################################################################################

if ( array_key_exists('action', $_GET) && $_GET['action'] == 'edit')
{
	$id = mysql_real_escape_string($_GET['id']);

	if (!empty($_POST))
	{
		$address = mysql_real_escape_string($_POST["address"]);
		$doctor_id = mysql_real_escape_string($_POST["doctor_id"]);
		$place_type_id = mysql_real_escape_string($_POST["place_type_id"]);
		$zone_id = mysql_real_escape_string($_POST["zone_id"]);
		
		$sql = 'UPDATE `doctor_zone` SET `address` = "' . $address . '", `doctor_id` = "' . $doctor_id . '", `place_type_id` = "' . $place_type_id . '", `zone_id` = "' . $zone_id . '" WHERE `id`=' . $id;
		mysql_query($sql) or die(mysql_error());

		header('Location: ' . $config["project"]["url"] . 'doctor_zone.php');
	}

	$rsa = mysql_query('SELECT * FROM `doctor_zone` WHERE `id`=' . $id);
	$form_row = mysql_fetch_assoc($rsa);
}
################################################################################

################################################################################
// Delete
################################################################################
if ( array_key_exists('action', $_GET) && $_GET['action'] == 'delete')
{
	$id = mysql_real_escape_string($_GET['id']);
	mysql_query('DELETE FROM `doctor_zone` WHERE `id`=' . $id) or die(mysql_error());
	header('Location: ' . $config["project"]["url"] . 'doctor_zone.php');
}
################################################################################

################################################################################
// Grid
################################################################################
$sql = 'SELECT * FROM `doctor_zone`';
$rsa = mysql_query($sql);

$grid = [];

while ($row = mysql_fetch_assoc($rsa))
{
	$grid[] = $row;
}
################################################################################

?><!DOCTYPE html>
<html>
<head>
	<title>Doctor Zone</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<?php include "navigation.php"; ?>

<h2>Doctor Zone</h2>

<br />

<form action="" method="post" >
<table align="center" width="500">
	<tr>
		<th>Id</th>
		<td><input type="text" name="id" value="<?php echo $form_row['id']; ?>" /></td>
	</tr>
	<tr>
		<th>Address</th>
		<td><input type="text" name="address" value="<?php echo $form_row['address']; ?>" /></td>
	</tr>
	<tr>
		<th>Doctor</th>
		<td>
			<select name="doctor_id">
				<option value=""> --- SELECT DOCTOR --- </option>
			<?php
			$sql = "SELECT * FROM `doctor`";
			$rsa = mysql_query($sql);
			while ($row = mysql_fetch_assoc($rsa))
			{
				$selected = $row["id"] == $form_row["doctor_id"] ? ' selected="selected"' : '';
				echo "<option value=" . $row["id"] . $selected . ">" . $row["name"] . "</option>";
			}
			?>
			</select>
		</td>
	</tr>
	<tr>
		<th>Place Type</th>
		<td>
			<select name="place_type_id">
				<option value=""> --- SELECT PLACE TYPE --- </option>
			<?php
			$sql = "SELECT * FROM `place_type`";
			$rsa = mysql_query($sql);
			while ($row = mysql_fetch_assoc($rsa))
			{
				$selected = $row["id"] == $form_row["place_type_id"] ? ' selected="selected"' : '';
				echo "<option value=" . $row["id"] . $selected . ">" . $row["name"] . "</option>";
			}
			?>
			</select>
		</td>
	</tr>
	<tr>
		<th>Zone</th>
		<td>
			<select name="zone_id">
				<option value=""> --- SELECT ZONE --- </option>
			<?php
			$sql = "SELECT * FROM `zone`";
			$rsa = mysql_query($sql);
			while ($row = mysql_fetch_assoc($rsa))
			{
				$selected = $row["id"] == $form_row["zone_id"] ? ' selected="selected"' : '';
				echo "<option value=" . $row["id"] . $selected . ">" . $row["name"] . "</option>";
			}
			?>
			</select>
		</td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" value="<?php echo empty($form_row['id']) ? 'Add':'Update'; ?>" /></td>
	</tr>
</table>
</form>

<br /> <br />

<table class="grid" cellspacing="0" cellpadding="0" width="800" align="center" >
	<tr>
		<th>Id</th>
		<th>Address</th>
		<th>Doctor</th>
		<th>Place Type</th>
		<th>Zone</th>
		<th>Actions</th>
	</tr>
<?php
	foreach ($grid as $row)
	{
		echo '	<tr>' . "\r\n";
		echo '		<td>' . $row['id'] . '</td>' . "\r\n";
		echo '		<td>' . $row['address'] . '</td>' . "\r\n";

		$sql = "SELECT * FROM `doctor` WHERE `id` = " . $row['doctor_id'];
		$result = mysql_fetch_assoc(mysql_query($sql));
		echo '		<td>' . $result['name'] . '</td>' . "\r\n";


		$sql = "SELECT * FROM `place_type` WHERE `id` = " . $row['place_type_id'];
		$result = mysql_fetch_assoc(mysql_query($sql));
		echo '		<td>' . $result['name'] . '</td>' . "\r\n";


		$sql = "SELECT * FROM `zone` WHERE `id` = " . $row['zone_id'];
		$result = mysql_fetch_assoc(mysql_query($sql));
		echo '		<td>' . $result['name'] . '</td>' . "\r\n";

		echo '		<td><a href="?action=edit&id=' . $row['id'] .  '"  >  Edit</a> <a href="?action=delete&id=' . $row['id'] . '">Delete</a></td>' . "\r\n";
		echo '	</tr>' . "\r\n";
	}
?>
</table>

</body>
</html>
