<?php

require_once "config.php";

check_login();


@mysql_connect($config["db"]["server"], $config["db"]["user"], $config["db"]["password"]) or die(mysql_error());
mysql_select_db($config["db"]["database"]) or die(mysql_error());

$form_row = [
	'id' => '',
	'disease_id' => '',
	'medicine_id' => '',
	'notes' => '',
];

################################################################################
# INSERT
################################################################################
if (!empty($_POST) && !array_key_exists('action', $_GET))
{
	$id = mysql_real_escape_string($_POST["id"]);
	$disease_id = mysql_real_escape_string($_POST["disease_id"]);
	$medicine_id = mysql_real_escape_string($_POST["medicine_id"]);
	$notes = mysql_real_escape_string($_POST["notes"]);
	
	if (empty($id))
	{
		$id = "NULL";
	}
	else
	{
		$id = '"' . $id . '"';
	}
	
	$sql = "INSERT INTO `disease_medicine` VALUES (" . $id . ", '" . $disease_id . "', '" . $medicine_id . "', '" . $notes . "')";
	mysql_query($sql) or die(mysql_error());
}
################################################################################

################################################################################
// Update
################################################################################

if ( array_key_exists('action', $_GET) && $_GET['action'] == 'edit')
{
	$id = mysql_real_escape_string($_GET['id']);

	if (!empty($_POST))
	{
		$disease_id = mysql_real_escape_string($_POST["disease_id"]);
		$medicine_id = mysql_real_escape_string($_POST["medicine_id"]);
		$notes = mysql_real_escape_string($_POST["notes"]);
		
		$sql = 'UPDATE `disease_medicine` SET `disease_id` = "' . $disease_id . '", `medicine_id` = "' . $medicine_id . '", `notes` = "' . $notes . '" WHERE `id`=' . $id;
		mysql_query($sql) or die(mysql_error());

		header('Location: ' . $config["project"]["url"] . 'disease_medicine.php');
	}

	$rsa = mysql_query('SELECT * FROM `disease_medicine` WHERE `id`=' . $id);
	$form_row = mysql_fetch_assoc($rsa);
}
################################################################################

################################################################################
// Delete
################################################################################
if ( array_key_exists('action', $_GET) && $_GET['action'] == 'delete')
{
	$id = mysql_real_escape_string($_GET['id']);
	mysql_query('DELETE FROM `disease_medicine` WHERE `id`=' . $id) or die(mysql_error());
	header('Location: ' . $config["project"]["url"] . 'disease_medicine.php');
}
################################################################################

################################################################################
// Grid
################################################################################
$sql = 'SELECT * FROM `disease_medicine`';
$rsa = mysql_query($sql);

$grid = [];

while ($row = mysql_fetch_assoc($rsa))
{
	$grid[] = $row;
}
################################################################################

?><!DOCTYPE html>
<html>
<head>
	<title>Disease Medicine</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<?php include "navigation.php"; ?>

<h2>Disease Medicine</h2>

<br />

<form action="" method="post" >
<table align="center" width="500">
	<tr>
		<th>Id</th>
		<td><input type="text" name="id" value="<?php echo $form_row['id']; ?>" /></td>
	</tr>
	<tr>
		<th>Disease</th>
		<td>
			<select name="disease_id">
				<option value=""> --- SELECT DISEASE --- </option>
			<?php
			$sql = "SELECT * FROM `disease`";
			$rsa = mysql_query($sql);
			while ($row = mysql_fetch_assoc($rsa))
			{
				$selected = $row["id"] == $form_row["disease_id"] ? ' selected="selected"' : '';
				echo "<option value=" . $row["id"] . $selected . ">" . $row["name"] . "</option>";
			}
			?>
			</select>
		</td>
	</tr>
	<tr>
		<th>Medicine</th>
		<td>
			<select name="medicine_id">
				<option value=""> --- SELECT MEDICINE --- </option>
			<?php
			$sql = "SELECT * FROM `medicine`";
			$rsa = mysql_query($sql);
			while ($row = mysql_fetch_assoc($rsa))
			{
				$selected = $row["id"] == $form_row["medicine_id"] ? ' selected="selected"' : '';
				echo "<option value=" . $row["id"] . $selected . ">" . $row["name"] . "</option>";
			}
			?>
			</select>
		</td>
	</tr>
	<tr>
		<th>Notes</th>
		<td><input type="text" name="notes" value="<?php echo $form_row['notes']; ?>" /></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" value="<?php echo empty($form_row['id']) ? 'Add':'Update'; ?>" /></td>
	</tr>
</table>
</form>

<br /> <br />

<table class="grid" cellspacing="0" cellpadding="0" width="800" align="center" >
	<tr>
		<th>Id</th>
		<th>Disease</th>
		<th>Medicine</th>
		<th>Notes</th>
		<th>Actions</th>
	</tr>
<?php
	foreach ($grid as $row)
	{
		echo '	<tr>' . "\r\n";
		echo '		<td>' . $row['id'] . '</td>' . "\r\n";

		$sql = "SELECT * FROM `disease` WHERE `id` = " . $row['disease_id'];
		$result = mysql_fetch_assoc(mysql_query($sql));
		echo '		<td>' . $result['name'] . '</td>' . "\r\n";


		$sql = "SELECT * FROM `medicine` WHERE `id` = " . $row['medicine_id'];
		$result = mysql_fetch_assoc(mysql_query($sql));
		echo '		<td>' . $result['name'] . '</td>' . "\r\n";

		echo '		<td>' . $row['notes'] . '</td>' . "\r\n";
		echo '		<td><a href="?action=edit&id=' . $row['id'] .  '"  >  Edit</a> <a href="?action=delete&id=' . $row['id'] . '">Delete</a></td>' . "\r\n";
		echo '	</tr>' . "\r\n";
	}
?>
</table>

</body>
</html>
