<?php  

require_once "config.php";


@mysql_connect($config["db"]["server"], $config["db"]["user"], $config["db"]["password"]) or die(mysql_error());
mysql_select_db($config["db"]["database"]) or die(mysql_error());


if ($_GET['id'])
{
	$sql = 'SELECT * FROM `bodyparts` WHERE `Bodyparts_id` =' . $_GET['id'];
}
else
{
	$sql ='SELECT * FROM `bodyparts` WHERE `Bodyparts_id` IS NULL';
}

$rsa = mysql_query($sql);

while($row = mysql_fetch_assoc($rsa))
{
	echo '<a href="?id=' . $row['id'] . '">' . $row['name'] . '</a> <br> ';
}