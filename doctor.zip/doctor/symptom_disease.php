<?php

require_once "config.php";

check_login();


@mysql_connect($config["db"]["server"], $config["db"]["user"], $config["db"]["password"]) or die(mysql_error());
mysql_select_db($config["db"]["database"]) or die(mysql_error());

$form_row = [
	'id' => '',
	'symptom_id' => '',
	'disease_id' => '',
];

################################################################################
# INSERT
################################################################################
if (!empty($_POST) && !array_key_exists('action', $_GET))
{
	$id = mysql_real_escape_string($_POST["id"]);
	$symptom_id = mysql_real_escape_string($_POST["symptom_id"]);
	$disease_id = mysql_real_escape_string($_POST["disease_id"]);
	
	if (empty($id))
	{
		$id = "NULL";
	}
	else
	{
		$id = '"' . $id . '"';
	}
	
	$sql = "INSERT INTO `symptom_disease` VALUES (" . $id . ", '" . $symptom_id . "', '" . $disease_id . "')";
	mysql_query($sql) or die(mysql_error());
}
################################################################################

################################################################################
// Update
################################################################################

if ( array_key_exists('action', $_GET) && $_GET['action'] == 'edit')
{
	$id = mysql_real_escape_string($_GET['id']);

	if (!empty($_POST))
	{
		$symptom_id = mysql_real_escape_string($_POST["symptom_id"]);
		$disease_id = mysql_real_escape_string($_POST["disease_id"]);
		
		$sql = 'UPDATE `symptom_disease` SET `symptom_id` = "' . $symptom_id . '", `disease_id` = "' . $disease_id . '" WHERE `id`=' . $id;
		mysql_query($sql) or die(mysql_error());

		header('Location: ' . $config["project"]["url"] . 'symptom_disease.php');
	}

	$rsa = mysql_query('SELECT * FROM `symptom_disease` WHERE `id`=' . $id);
	$form_row = mysql_fetch_assoc($rsa);
}
################################################################################

################################################################################
// Delete
################################################################################
if ( array_key_exists('action', $_GET) && $_GET['action'] == 'delete')
{
	$id = mysql_real_escape_string($_GET['id']);
	mysql_query('DELETE FROM `symptom_disease` WHERE `id`=' . $id) or die(mysql_error());
	header('Location: ' . $config["project"]["url"] . 'symptom_disease.php');
}
################################################################################

################################################################################
// Grid
################################################################################
$sql = 'SELECT * FROM `symptom_disease`';
$rsa = mysql_query($sql);

$grid = [];

while ($row = mysql_fetch_assoc($rsa))
{
	$grid[] = $row;
}
################################################################################

?><!DOCTYPE html>
<html>
<head>
	<title>Symptom Disease</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<?php include "navigation.php"; ?>

<h2>Symptom Disease</h2>

<br />

<form action="" method="post" >
<table align="center" width="500">
	<tr>
		<th>Id</th>
		<td><input type="text" name="id" value="<?php echo $form_row['id']; ?>" /></td>
	</tr>
	<tr>
		<th>Symptom</th>
		<td>
			<select name="symptom_id">
				<option value=""> --- SELECT SYMPTOM --- </option>
			<?php
			$sql = "SELECT * FROM `symptom`";
			$rsa = mysql_query($sql);
			while ($row = mysql_fetch_assoc($rsa))
			{
				$selected = $row["id"] == $form_row["symptom_id"] ? ' selected="selected"' : '';
				echo "<option value=" . $row["id"] . $selected . ">" . $row["name"] . "</option>";
			}
			?>
			</select>
		</td>
	</tr>
	<tr>
		<th>Disease</th>
		<td>
			<select name="disease_id">
				<option value=""> --- SELECT DISEASE --- </option>
			<?php
			$sql = "SELECT * FROM `disease`";
			$rsa = mysql_query($sql);
			while ($row = mysql_fetch_assoc($rsa))
			{
				$selected = $row["id"] == $form_row["disease_id"] ? ' selected="selected"' : '';
				echo "<option value=" . $row["id"] . $selected . ">" . $row["name"] . "</option>";
			}
			?>
			</select>
		</td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" value="<?php echo empty($form_row['id']) ? 'Add':'Update'; ?>" /></td>
	</tr>
</table>
</form>

<br /> <br />

<table class="grid" cellspacing="0" cellpadding="0" width="800" align="center" >
	<tr>
		<th>Id</th>
		<th>Symptom</th>
		<th>Disease</th>
		<th>Actions</th>
	</tr>
<?php
	foreach ($grid as $row)
	{
		echo '	<tr>' . "\r\n";
		echo '		<td>' . $row['id'] . '</td>' . "\r\n";

		$sql = "SELECT * FROM `symptom` WHERE `id` = " . $row['symptom_id'];
		$result = mysql_fetch_assoc(mysql_query($sql));
		echo '		<td>' . $result['name'] . '</td>' . "\r\n";


		$sql = "SELECT * FROM `disease` WHERE `id` = " . $row['disease_id'];
		$result = mysql_fetch_assoc(mysql_query($sql));
		echo '		<td>' . $result['name'] . '</td>' . "\r\n";

		echo '		<td><a href="?action=edit&id=' . $row['id'] .  '"  >  Edit</a> <a href="?action=delete&id=' . $row['id'] . '">Delete</a></td>' . "\r\n";
		echo '	</tr>' . "\r\n";
	}
?>
</table>

</body>
</html>
