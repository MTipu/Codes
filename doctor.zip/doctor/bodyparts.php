<?php

require_once "config.php";

check_login();


@mysql_connect($config["db"]["server"], $config["db"]["user"], $config["db"]["password"]) or die(mysql_error());
mysql_select_db($config["db"]["database"]) or die(mysql_error());

$form_row = [
	'id' => '',
	'name' => '',
	'Bodyparts_id' => '',
];

################################################################################
# INSERT
################################################################################
if (!empty($_POST) && !array_key_exists('action', $_GET))
{
	$id = mysql_real_escape_string($_POST["id"]);
	$name = mysql_real_escape_string($_POST["name"]);
	$Bodyparts_id = mysql_real_escape_string($_POST["Bodyparts_id"]);
	
	if (empty($id))
	{
		$id = "NULL";
	}
	else
	{
		$id = '"' . $id . '"';
	}
	
	$sql = "INSERT INTO `bodyparts` VALUES (" . $id . ", '" . $name . "', '" . $Bodyparts_id . "')";
	mysql_query($sql) or die(mysql_error());
}
################################################################################

################################################################################
// Update
################################################################################

if ( array_key_exists('action', $_GET) && $_GET['action'] == 'edit')
{
	$id = mysql_real_escape_string($_GET['id']);

	if (!empty($_POST))
	{
		$name = mysql_real_escape_string($_POST["name"]);
		$Bodyparts_id = mysql_real_escape_string($_POST["Bodyparts_id"]);
		
		$sql = 'UPDATE `bodyparts` SET `name` = "' . $name . '", `Bodyparts_id` = "' . $Bodyparts_id . '" WHERE `id`=' . $id;
		mysql_query($sql) or die(mysql_error());

		header('Location: ' . $config["project"]["url"] . 'bodyparts.php');
	}

	$rsa = mysql_query('SELECT * FROM `bodyparts` WHERE `id`=' . $id);
	$form_row = mysql_fetch_assoc($rsa);
}
################################################################################

################################################################################
// Delete
################################################################################
if ( array_key_exists('action', $_GET) && $_GET['action'] == 'delete')
{
	$id = mysql_real_escape_string($_GET['id']);
	mysql_query('DELETE FROM `bodyparts` WHERE `id`=' . $id) or die(mysql_error());
	header('Location: ' . $config["project"]["url"] . 'bodyparts.php');
}
################################################################################

################################################################################
// Grid
################################################################################
$sql = 'SELECT * FROM `bodyparts`';
$rsa = mysql_query($sql);

$grid = [];

while ($row = mysql_fetch_assoc($rsa))
{
	$grid[] = $row;
}
################################################################################

?><!DOCTYPE html>
<html>
<head>
	<title>Bodyparts</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<?php include "navigation.php";  ?>

<h2>Bodyparts</h2>

<br />

<form action="" method="post" >
<table align="center" width="500">
	<tr>
		<th>Id</th>
		<td><input type="text" name="id" value="<?php echo $form_row['id']; ?>" /></td>
	</tr>
	<tr>
		<th>Name</th>
		<td><input type="text" name="name" value="<?php echo $form_row['name']; ?>" /></td>
	</tr>
	<tr>
		<th>Bodyparts</th>
		<td>
			<select name="Bodyparts_id">
				<option value=""> --- SELECT BODYPARTS --- </option>
			<?php
			$sql = "SELECT * FROM `bodyparts`";
			$rsa = mysql_query($sql);
			while ($row = mysql_fetch_assoc($rsa))
			{
				$selected = $row["id"] == $form_row["Bodyparts_id"] ? ' selected="selected"' : '';
				echo "<option value=" . $row["id"] . $selected . ">" . $row["id"] . "</option>";
			}
			?>
			</select>
		</td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" value="<?php echo empty($form_row['id']) ? 'Add':'Update'; ?>" /></td>
	</tr>
</table>
</form>

<br /> <br />

<table class="grid" cellspacing="0" cellpadding="0" width="800" align="center" >
	<tr>
		<th>Id</th>
		<th>Name</th>
		<th>Bodyparts</th>
		<th>Actions</th>
	</tr>
<?php
	foreach ($grid as $row)
	{
		echo '	<tr>' . "\r\n";
		echo '		<td>' . $row['id'] . '</td>' . "\r\n";
		echo '		<td>' . $row['name'] . '</td>' . "\r\n";

		$sql = "SELECT * FROM `bodyparts` WHERE `id` = " . $row['Bodyparts_id'];
		$result = mysql_fetch_assoc(mysql_query($sql));
		echo '		<td>' . $result['id'] . '</td>' . "\r\n";

		echo '		<td><a href="?action=edit&id=' . $row['id'] .  '"  >  Edit</a> <a href="?action=delete&id=' . $row['id'] . '">Delete</a></td>' . "\r\n";
		echo '	</tr>' . "\r\n";
	}
?>
</table>

</body>
</html>
