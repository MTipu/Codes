<?php

class Student
{
	public static function insert($id, $name, $age)
	{
		$id = mysql_real_escape_string($id);
		$name = mysql_real_escape_string($name);
		$age = mysql_real_escape_string($age);

		if (empty($id))
		{
			$id = 'NULL';
		}
		else
		{
			$id = '"' . $id . '"';
		}

		$sql = 'INSERT INTO `student` (`id`, `name`, `age`) VALUES (' . $id . ',"' . $name . '","' . $age . '")';

		mysql_query($sql) or die(mysql_error());
	}

	public static function update($id, $name, $age)
	{
		$id = mysql_real_escape_string($id);
		$name = mysql_real_escape_string($name);
		$age = mysql_real_escape_string($age);

		if (empty($id))
		{
			$id = 'NULL';
		}
		else
		{
			$id = '"' . $id . '"';
		}

		$sql = 'UPDATE `student` set `name`="' . $name . '", `age`="' . $age . '" WHERE `id`=' . $id;

		mysql_query($sql) or die(mysql_error());
	}

	public static function delete($id)
	{
		$id = mysql_real_escape_string($id);
		$sql = 'DELETE FROM `student` WHERE `id`=' . $id;

		mysql_query($sql) or die(mysql_error());
	}

	public static function count()
	{
		$sql = 'SELECT count(*) as `count` FROM `student`';
		$rsa = mysql_query($sql);
		$row = mysql_fetch_assoc($rsa);
		return $row['count'];
	}

	public static function all($key = null, $page = null, $per_page = null)
	{
		if ($page != null && $per_page != null)
		{
			$count = Student::count();
			$offset = $per_page * ($page - 1);
			$limit = $per_page;

			$sql = 'SELECT * FROM `student` LIMIT ' . $limit . ' OFFSET ' . $offset;
		}
		else
		{
			$sql = 'SELECT * FROM `student`';
		}

		$rsa = mysql_query($sql);

		$arr = [];

		while ($row = mysql_fetch_assoc($rsa))
		{
			if ($key == null)
			{
				$arr[] = $row;
			}
			else
			{
				if (array_key_exists($key, $row))
				{
					$arr[$row[$key]] = $row;
				}
				else
				{
					$arr[] = $row;
				}
			}
		}

		return $arr;
	}


	public static function by_id($id)
	{
		$id = mysql_real_escape_string($id);
		$sql = 'SELECT * FROM `student` WHERE `id`="' . $id . '"';
		$rsa = mysql_query($sql);

		while ($row = mysql_fetch_assoc($rsa))
		{
			return $row;
		}

		return false;
	}
}