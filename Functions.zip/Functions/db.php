<?php

function db_connect()
{
	@mysql_connect("localhost", "root", "123456") or die(mysql_error());
	mysql_select_db("test") or die(mysql_error());
}
