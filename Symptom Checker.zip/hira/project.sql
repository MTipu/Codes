-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 18, 2017 at 03:59 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `disease_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`disease_id`, `doctor_id`) VALUES
(2, 1),
(2, 5);

-- --------------------------------------------------------

--
-- Table structure for table `medi`
--

CREATE TABLE `medi` (
  `disease_id` int(11) NOT NULL,
  `medi_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `medi`
--

INSERT INTO `medi` (`disease_id`, `medi_id`) VALUES
(2, 1),
(2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `sp_admin`
--

CREATE TABLE `sp_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sp_admin`
--

INSERT INTO `sp_admin` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `sp_age`
--

CREATE TABLE `sp_age` (
  `age_id` int(11) NOT NULL,
  `min_age` int(11) NOT NULL,
  `max_age` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sp_age`
--

INSERT INTO `sp_age` (`age_id`, `min_age`, `max_age`) VALUES
(17, 1, 5),
(18, 6, 10),
(21, 11, 15),
(22, 16, 20),
(23, 21, 26);

-- --------------------------------------------------------

--
-- Table structure for table `sp_bodypart`
--

CREATE TABLE `sp_bodypart` (
  `bodypart_id` int(11) NOT NULL,
  `bodypart_name` varchar(45) NOT NULL,
  `gender_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sp_bodypart`
--

INSERT INTO `sp_bodypart` (`bodypart_id`, `bodypart_name`, `gender_id`) VALUES
(1, 'Head', 1),
(2, 'Head', 2),
(3, 'Legs', 1),
(4, 'Legs', 2),
(5, 'Arm', 1),
(6, 'Arm', 2),
(7, 'Foot', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sp_bodysubpart`
--

CREATE TABLE `sp_bodysubpart` (
  `subpart_id` int(11) NOT NULL,
  `subpart_name` varchar(45) NOT NULL,
  `bodypart_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `sp_bodysubpart`
--

INSERT INTO `sp_bodysubpart` (`subpart_id`, `subpart_name`, `bodypart_id`) VALUES
(1, 'Scalp', 1),
(2, 'Eye', 1),
(3, 'Scalp', 2),
(4, 'Eye', 2),
(5, 'Ear', 1),
(6, 'Ear', 2),
(7, 'Shoulder', 5),
(8, 'Elbow', 5),
(9, 'Knee', 4),
(10, 'Toe', 7);

-- --------------------------------------------------------

--
-- Table structure for table `sp_disease`
--

CREATE TABLE `sp_disease` (
  `disease_id` int(11) NOT NULL,
  `disease_name` varchar(220) NOT NULL,
  `age` int(11) NOT NULL,
  `bodypart` int(11) NOT NULL,
  `bodysubpart` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sp_disease`
--

INSERT INTO `sp_disease` (`disease_id`, `disease_name`, `age`, `bodypart`, `bodysubpart`) VALUES
(2, 'Fiver', 18, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `sp_doctor`
--

CREATE TABLE `sp_doctor` (
  `doctor_id` int(11) NOT NULL,
  `doctor_name` varchar(220) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sp_doctor`
--

INSERT INTO `sp_doctor` (`doctor_id`, `doctor_name`) VALUES
(1, 'Muhammad Saim'),
(2, 'Kamran Akram'),
(3, 'Talha Khan'),
(4, 'Ali Khan'),
(5, 'Nazia Latif');

-- --------------------------------------------------------

--
-- Table structure for table `sp_gender`
--

CREATE TABLE `sp_gender` (
  `gender_id` int(11) NOT NULL,
  `gender_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sp_gender`
--

INSERT INTO `sp_gender` (`gender_id`, `gender_name`) VALUES
(1, 'male'),
(2, 'female');

-- --------------------------------------------------------

--
-- Table structure for table `sp_medi`
--

CREATE TABLE `sp_medi` (
  `medi_id` int(11) NOT NULL,
  `medi_name` varchar(220) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sp_medi`
--

INSERT INTO `sp_medi` (`medi_id`, `medi_name`) VALUES
(1, 'Panadole'),
(2, 'Desprin'),
(3, 'Asprin');

-- --------------------------------------------------------

--
-- Table structure for table `sp_symptoms`
--

CREATE TABLE `sp_symptoms` (
  `symptoms_id` int(11) NOT NULL,
  `symptoms_name` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sp_symptoms`
--

INSERT INTO `sp_symptoms` (`symptoms_id`, `symptoms_name`) VALUES
(1, 'Headache'),
(2, 'Cough'),
(3, 'Blood in mouth'),
(4, 'Pain in stomech'),
(5, 'Pain in tharote');

-- --------------------------------------------------------

--
-- Table structure for table `symptoms`
--

CREATE TABLE `symptoms` (
  `disease_id` int(11) NOT NULL,
  `symptoms_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `symptoms`
--

INSERT INTO `symptoms` (`disease_id`, `symptoms_id`) VALUES
(2, 1),
(2, 2),
(2, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sp_admin`
--
ALTER TABLE `sp_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sp_age`
--
ALTER TABLE `sp_age`
  ADD PRIMARY KEY (`age_id`);

--
-- Indexes for table `sp_bodypart`
--
ALTER TABLE `sp_bodypart`
  ADD PRIMARY KEY (`bodypart_id`),
  ADD KEY `genderid_idx` (`gender_id`);

--
-- Indexes for table `sp_bodysubpart`
--
ALTER TABLE `sp_bodysubpart`
  ADD PRIMARY KEY (`subpart_id`),
  ADD KEY `bodypartid_idx` (`bodypart_id`);

--
-- Indexes for table `sp_disease`
--
ALTER TABLE `sp_disease`
  ADD PRIMARY KEY (`disease_id`);

--
-- Indexes for table `sp_doctor`
--
ALTER TABLE `sp_doctor`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `sp_gender`
--
ALTER TABLE `sp_gender`
  ADD PRIMARY KEY (`gender_id`);

--
-- Indexes for table `sp_medi`
--
ALTER TABLE `sp_medi`
  ADD PRIMARY KEY (`medi_id`);

--
-- Indexes for table `sp_symptoms`
--
ALTER TABLE `sp_symptoms`
  ADD PRIMARY KEY (`symptoms_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sp_admin`
--
ALTER TABLE `sp_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `sp_age`
--
ALTER TABLE `sp_age`
  MODIFY `age_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `sp_bodypart`
--
ALTER TABLE `sp_bodypart`
  MODIFY `bodypart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `sp_bodysubpart`
--
ALTER TABLE `sp_bodysubpart`
  MODIFY `subpart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `sp_disease`
--
ALTER TABLE `sp_disease`
  MODIFY `disease_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `sp_doctor`
--
ALTER TABLE `sp_doctor`
  MODIFY `doctor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `sp_medi`
--
ALTER TABLE `sp_medi`
  MODIFY `medi_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `sp_symptoms`
--
ALTER TABLE `sp_symptoms`
  MODIFY `symptoms_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `sp_bodypart`
--
ALTER TABLE `sp_bodypart`
  ADD CONSTRAINT `gender_id` FOREIGN KEY (`gender_id`) REFERENCES `sp_gender` (`gender_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sp_bodysubpart`
--
ALTER TABLE `sp_bodysubpart`
  ADD CONSTRAINT `bodypart_id` FOREIGN KEY (`bodypart_id`) REFERENCES `sp_bodypart` (`bodypart_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
