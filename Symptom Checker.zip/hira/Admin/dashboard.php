<?php
session_start();
if (isset($_SESSION['ID'])) {
    ?>
    <html>
        <head>
            <link href="../semantic-ui/dist/semantic.css" rel="stylesheet"/>
            <script src="../js/jquery-3.1.1.js" type="text/javascript"></script>
            <script src="../semantic-ui/dist/semantic.js"></script>
        </head>
        <body>
            <div style="display: table; margin: 0 auto; margin-top: 100px; ">
                <a href="addage.php"><button class="ui button red">Add Age Range</button></a>
                <a href="adddiseases.php"><button class="ui button red">Add Diseases</button></a>
                <a href="addpart.php"><button class="ui button red">Add Body Part</button></a>
                <a href="addsubpart.php"><button class="ui button red">Add Sub Part</button></a>
                <a href="addsymptoms.php"><button class="ui button red">Add Symptoms</button></a>
                <a href="adddoctor.php"><button class="ui button red">Add Doctor</button></a>
                <a href="addmedi.php"><button class="ui button red">Add Medi</button></a>
            </div>
        </body>
    </html>

    <?php
} else {
    header("Location: index.php");
}