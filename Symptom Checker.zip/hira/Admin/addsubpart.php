<?php
session_start();
if (isset($_SESSION['ID'])) {
    ?>
    <html>
        <head>
            <link href="../semantic-ui/dist/semantic.css" rel="stylesheet"/>
            <script src="../semantic-ui/dist/semantic.js"></script>
        </head>
        <body style="margin: 0 auto;">
            <br>
            <br>
            <br>
            <div style="width: 60%; margin:  0 auto;">
                <form class="ui form" action="process/addsubpartprocess.php" method="POST">
                    <?php
                    $host = "localhost";
                    $user = "root";
                    $pass = "";
                    $db = "project";

                    $link = mysqli_connect($host, $user, $pass, $db) or die("Unable to connect");
                    $query = "SELECT * FROM sp_bodypart";
                    $res = mysqli_query($link, $query);
                    ?>
                    <div class="field">
                        <label>Select main body part</label>
                        <select name="part">
                            <option value="">Select main part</option>
                            <?php
                            while ($row = mysqli_fetch_array($res)) {
                                $query2 = "SELECT * FROM sp_gender WHERE gender_id='" . $row['gender_id'] . "'";
                                $row2 = mysqli_fetch_array(mysqli_query($link, $query2));
                                ?>
                                <option value="<?php echo $row['bodypart_id']; ?>"><?php echo $row['bodypart_name'] . " (" . $row2['gender_name'] . ")"; ?></option>
                                <?php
                            }
                            ?>

                        </select>
                    </div>
                    <div class="field">
                        <label>Enter body part</label>
                        <input type="text" name="subpart" placeholder="Head">
                    </div>

                    <div class="field">
                        <button class="ui button">Add</button>
                    </div>
                </form>
            </div>
        </body>
    </html>

    <?php
} else {
    header("Location: index.php");
}