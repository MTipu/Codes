<?php
session_start();
if (isset($_SESSION['ID'])) {
    ?>
    <html>
        <head>
            <link href="../semantic-ui/dist/semantic.css" rel="stylesheet"/>
            <script src="../js/jquery-3.1.1.js" type="text/javascript"></script>
            <script src="../semantic-ui/dist/semantic.js"></script>
            <script>
                $(document).ready(function () {
                    $('#bodypart').on("change", function (e) {
                        var part_id = $('#bodypart').val();
                        jQuery.post("./process/selectbodyarea.php",
                                {
                                    part_id: part_id
                                }, function (data) {
                            $('#bodyarea').html(data);
                        });
                    });
                    $('#field_2').hide();
                    $('#field_3').hide();
                    $('#field_4').hide();
                    $('#field_5').hide();
                    $('#field_6').hide();
                    $('#field_7').hide();
                    $('#submit_button').hide();
                    $('#next_button').click(function () {
                        next_process();
                    });
                    $('#prev_button').click(function () {
                        prev_process();
                    });
                    $('.ui.fluid.dropdown').dropdown();
                });
                var count = 1;
                function next_process() {
                    if (count < 7) {
                        $.when($('#field_' + count).transition('slide right')).done(function () {
                            setTimeout(function () {
                                count++;
                                $('#field_' + count).transition('slide left');
                                if (count == 7) {
                                    $('#submit_button').show();
                                }
                            }, 500);

                        });
                    }

                }
                function prev_process() {
                    if (count > 1) {
                        $('#submit_button').hide();
                        $.when($('#field_' + count).transition('slide left')).done(function () {
                            setTimeout(function () {
                                count--;
                                $('#field_' + count).transition('slide right');
                            }, 500);
                        });
                    }


                }
                

            </script>
        </head>
        <body style="margin: 0 auto;">
            <br>
            <br>
            <br>
            <button style="position: absolute; left: 50; top: 100;" id="prev_button" type="button" class="ui button">Previous</button>
            <button style="position: absolute; right: 50; top: 100;" id="next_button" type="button" class="ui button">Next</button>

            <div style="width: 800px; margin:  0 auto;">
                <form class="ui form" id="form1" action="process/adddisease.php" method="POST">
                    <div class="field" id="field_1">
                        <label>Enter Disease Name</label>
                        <input type="text" name="name" required=""/>
                    </div>
                    <?php
                    $host = "localhost";
                    $user = "root";
                    $pass = "";
                    $db = "project";

                    $link = mysqli_connect($host, $user, $pass, $db) or die("Unable to connect");
                    $query = "SELECT * FROM sp_age";
                    $res = mysqli_query($link, $query);
                    ?>
                    <div class="field" id="field_2">
                        <label>Age Range</label>
                        <select required="" name="age">
                            <?php
                            while ($row = mysqli_fetch_array($res)) {
                                echo "<option value='" . $row['age_id'] . "'>" . $row['min_age'] . " - " . $row['max_age'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <?php
                    $query = "SELECT * FROM sp_bodypart";
                    $res = mysqli_query($link, $query);
                    ?>
                    <div class="field" id="field_3">
                        <label>Select Bodypart</label>
                        <select name="part" id="bodypart" required="">
                            <option selected="" disabled=""></option>
                            <?php
                            while ($row = mysqli_fetch_array($res)) {
                                $query2 = "SELECT * FROM sp_gender WHERE gender_id = '" . $row['gender_id'] . "'";
                                $res2 = mysqli_query($link, $query2);
                                $row2 = mysqli_fetch_array($res2);
                                echo "<option value='" . $row['bodypart_id'] . "'>" . $row['bodypart_name'] . " (" . $row2['gender_name'] . ")</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="field" id="field_4">
                        <label>Select Body Area</label>
                        <select name="subpart" id="bodyarea" required="">
                            
                        </select>
                    </div>
                    <div class="field" id="field_5">                
                    <label>Symptoms</label>
                        <select name="symptoms[]" required="" multiple="multiple" class="ui fluid dropdown" id="multi-select">
                             <?php
                             $query3 = "SELECT * FROM `sp_symptoms`";
                                $res3 = mysqli_query($link, $query3);
                            while ($row3 = mysqli_fetch_array($res3)) {
                                
                                echo "<option value='" . $row3['symptoms_id'] . "'>" . $row3['symptoms_name'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="field" id="field_6">                
                    <label>Doctors</label>
                        <select name="doctor[]" required="" multiple="multiple" class="ui fluid dropdown">
                             <?php
                             $query4 = "SELECT * FROM `sp_doctor`";
                                $res4 = mysqli_query($link, $query4);
                            while ($row4 = mysqli_fetch_array($res4)) {
                                
                                echo "<option value='" . $row4['doctor_id'] . "'>" . $row4['doctor_name'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="field" id="field_7">                
                    <label>Medicines</label>
                        <select name="medi[]" required="" multiple="multiple" class="ui fluid  dropdown">
                             <?php
                             $query5 = "SELECT * FROM `sp_medi`";
                                $res5 = mysqli_query($link, $query5);
                            while ($row5 = mysqli_fetch_array($res5)) {
                                
                                echo "<option value='" . $row5['medi_id'] . "'>" . $row5['medi_name'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="field">

                    </div>
                    <br>
                    <div class="field" id="submit_button">
                        <button class="ui fluid blue button">Add</button>
                    </div>
                </form>
            </div>
        </body>
    </html>

    <script>
        $(function(){
            $('#bodypart').change( function(){
                var bodypart = $(this).val();
                console.log(bodypart);
                $.post('subbodyparts.php',{bodypart:bodypart},function(data){
                    $("#bodyarea").html(data);
                });
            });
        });
    </script>

    <?php
} else {
    header("Location: index.php");
}