<?php 
	
$host = "localhost";
$user = "root";
$pass = "";
$db = "project";

$link = mysqli_connect($host, $user, $pass, $db) or die("Unable to connect");
	
	$name = $_POST['name'];
	$age = $_POST['age'];
	$bodypart = $_POST['part'];
	$bodysubpart = $_POST['subpart'];
	

	$symptoms = $_POST['symptoms'];
	$doctor = $_POST['doctor'];
	$medi = $_POST['medi'];



$quer1 = "INSERT INTO `sp_disease` (disease_name,age,bodypart,bodysubpart) VALUES ('$name','$age','$bodypart','$bodysubpart')";

$res1 = mysqli_query($link, $quer1);

if($res1){
	$last_id = mysqli_insert_id($link);

	//loop for symptoms

	foreach ($symptoms as $value) {
			$query2 = "INSERT INTO `symptoms` (disease_id, symptoms_id) VALUES ('$last_id', '$value')";
			mysqli_query($link, $query2);
	}//symptoms foreach loops
	foreach ($doctor as $value1) {
			$query3 = "INSERT INTO `doctor` (disease_id, doctor_id) VALUES ('$last_id', '$value1')";
			mysqli_query($link, $query3);
	}//doctor foreach loops
	foreach ($medi as $value2) {
			$query4 = "INSERT INTO `medi` (disease_id, medi_id) VALUES ('$last_id', '$value2')";
			mysqli_query($link, $query4);
	}//medi foreach loops

}//first query exicute if






 ?>