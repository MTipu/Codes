<?php 

$host = "localhost";
$user = "root";
$pass = "";
$db = "project";

$link = mysqli_connect($host, $user, $pass, $db) or die("Unable to connect");

$doctor = mysqli_real_escape_string($link,$_POST['doctor']);

$query = "INSERT INTO `sp_doctor` (doctor_name) VALUES ('$doctor')";

if(mysqli_query($link,$query)){

	header('Location: ../adddoctor.php');
}else{
	echo "Error";
}



 ?>