<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "project";

$link = mysqli_connect($host, $user, $pass, $db) or die("Unable to connect");

$min = mysqli_real_escape_string($link, $_POST['min']);

$max = mysqli_real_escape_string($link, $_POST['max']);
if ($min >= $max) {
    $error = "Min age range must be smaller.";
} else {
    $query = "SELECT * FROM sp_age WHERE '$min' BETWEEN min_age AND max_age";
    $res = mysqli_query($link, $query);
    if (mysqli_num_rows($res) > 0) {
        $error = "Invalid age range, min age range already exists between min and max range.";
    } else {
        $query = "SELECT * FROM sp_age WHERE min_age = '$min'";
        $res = mysqli_query($link, $query);
        if (mysqli_num_rows($res) > 0) {
            $error = "Min age range already exists.";
        } else {
            $query = "SELECT * FROM sp_age WHERE max_age = '$max'";
            $res = mysqli_query($link, $query);
            if (mysqli_num_rows($res) > 0) {
                $error = "Max age range already exists.";
            } else {
                $query = "INSERT INTO sp_age (min_age, max_age) VALUES ('$min','$max')";
                if (mysqli_query($link, $query)) {
                    header("Location: ../addage.php");
                } else {
                    echo 'Error';
                }
            }
        }
    }
}
if (isset($error) and $error != "") {
    echo $error;
}


