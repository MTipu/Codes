<?php 



$host = "localhost";
$user = "root";
$pass = "";
$db = "project";

$link = mysqli_connect($host, $user, $pass, $db) or die("Unable to connect");

$medi = mysqli_real_escape_string($link,$_POST['medi']);

$query = "INSERT INTO `sp_medi` (medi_name) VALUES ('$medi')";

if(mysqli_query($link,$query)){

	header('Location: ../addmedi.php');
}else{
	echo "Error";
}



 ?>