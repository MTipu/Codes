<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "project";

$link = mysqli_connect($host, $user, $pass, $db) or die("Unable to connect");
$part = mysqli_real_escape_string($link, $_POST['part_id']);
$query = "SELECT * FROM sp_bodyarea WHERE bodypart_id = '$part'";
$res = mysqli_query($link, $query);
while($row = mysqli_fetch_array($res)){
    echo "<option value='".$row['bodyarea_id']."'>".$row['bodyarea_name']."</option>";
}