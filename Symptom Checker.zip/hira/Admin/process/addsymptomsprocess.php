<?php 



$host = "localhost";
$user = "root";
$pass = "";
$db = "project";

$link = mysqli_connect($host, $user, $pass, $db) or die("Unable to connect");

$symptom = mysqli_real_escape_string($link,$_POST['symptom']);

$query = "INSERT INTO `sp_symptoms` (symptoms_name) VALUES ('$symptom')";

if(mysqli_query($link,$query)){

	header('Location: ../addsymptoms.php');
}else{
	echo "Error";
}



 ?>