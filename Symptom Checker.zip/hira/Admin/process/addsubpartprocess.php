<?php

$part = $_POST['part'];
$subpart = $_POST['subpart'];

$host = "localhost";
$user = "root";
$pass = "";
$db = "project";

$link = mysqli_connect($host, $user, $pass, $db) or die("Unable to connect");


$query = "INSERT INTO sp_bodysubpart (subpart_name, bodypart_id) VALUES ('$subpart','$part')";
if(mysqli_query($link, $query)){
    header("Location: ../addsubpart.php");
} else{
    echo 'Error';
}