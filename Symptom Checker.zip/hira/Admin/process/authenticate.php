<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "project";

$con = mysqli_connect($host, $user, $pass, $db) or die("Unable to connect");

$username = $_POST['username'];
$password = $_POST['password'];

$query = "SELECT * FROM sp_admin WHERE username='$username' AND password='$password'";
$res = mysqli_query($con, $query);
if(mysqli_num_rows($res)>0){
    $row = mysqli_fetch_array($res);
    session_start();
    $_SESSION['ID'] = $row['id'];
    header("Location: ../dashboard.php");
} else{
    echo 'Invalid Credentials';
}
