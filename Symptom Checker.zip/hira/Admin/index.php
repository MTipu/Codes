<html>
    
    <head></head>
    <body>
        <form method="POST" action="process/authenticate.php">
            <input type="text" name="username" placeholder="Username">
            <br>
            <input type="password" name="password" placeholder="Password">
            <br>
            <button type="submit">Login</button>
        </form>
    </body>
</html>