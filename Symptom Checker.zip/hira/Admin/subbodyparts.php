<?php 

$host = "localhost";
$user = "root";
$pass = "";
$db = "project";

$link = mysqli_connect($host, $user, $pass, $db) or die("Unable to connect");

if( isset($_POST['bodypart']) && !empty($_POST['bodypart']) ){

	$bodypart = $_POST['bodypart'];

	$sql = "SELECT * FROM `sp_bodysubpart` WHERE bodypart_id = $bodypart";

	$res = mysqli_query($link, $sql);


//echo '<select name="subpart" id="bodyarea" required="">';
                            
                        
	while($row = mysqli_fetch_assoc($res)){ ?>

		<option value="<?php echo $row['subpart_id']; ?>"> <?php echo $row['subpart_name']; ?></option>;

<?php	}
//echo '</select>';


}
                            










 ?>