<?php
session_start();
if (isset($_SESSION['ID'])) {
    ?>
    <html>
        <head>
            <link href="../semantic-ui/dist/semantic.css" rel="stylesheet"/>
            <script src="../js/jquery-3.1.1.js" type="text/javascript"></script>
            <script src="../semantic-ui/dist/semantic.js"></script>
            <script>
                $(document).ready(function () {
                    $('#form1').submit(function (e) {
                        e.preventDefault();
                        var min = parseInt($('#min').val());
                        var max = parseInt($('#max').val());
                        
                        if (min >= max){
                            alert("min = " + min + "\nmax = " + max + "\n Invalid Age Range");
                        } else{
                            this.submit();
                        }
                    });
                });
            </script>
        </head>
        <body style="margin: 0 auto;">
            <br>
            <br>
            <br>
            <div style="width: 60%; margin:  0 auto;">
                <form class="ui form" id="form1" action="process/addageprocess.php" method="POST">
                    <div class="field">
                        <label>Enter age range</label>
                    </div>
                    <div class="two fields">
                        <div class="four wide field">
                            <input type="number" name="min" placeholder="min" id="min">
                        </div>
                        <div class="four wide field">    
                            <input type="number" name="max" placeholder="max" id="max">
                        </div>
                    </div>

                    <div class="field">
                        <button class="ui button">Add</button>
                    </div>
                </form>
            </div>
        </body>
    </html>

    <?php
} else {
    header("Location: index.php");
}