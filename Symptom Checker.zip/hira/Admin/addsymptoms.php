<?php
session_start();
if (isset($_SESSION['ID'])) {
    ?>
    <html>
        <head>
            <link href="../semantic-ui/dist/semantic.css" rel="stylesheet"/>
            <script src="../js/jquery-3.1.1.js" type="text/javascript"></script>
            <script src="../semantic-ui/dist/semantic.js"></script>
            <script>
                $(document).ready(function () {
                    $('.ui.fluid.search.dropdown').dropdown();
                });
            </script>
        </head>
        <body style="margin: 0 auto;">
            <br>
            <br>
            <br>
            <div style="width: 60%; margin:  0 auto;">
                <form class="ui form" id="form1" action="process/addsymptomsprocess.php" method="POST">
                    <div class="field">
                        <label>Enter Symptom</label>
                        <input type="text" name="symptom"/>
                    </div>

                    <div class="field">
                        <button class="ui button" type="submit">Add</button>
                    </div>
                </form>
            </div>
        </body>
    </html>

    <?php
} else {
    header("Location: index.php");
}