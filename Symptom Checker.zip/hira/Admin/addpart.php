<?php
session_start();
if (isset($_SESSION['ID'])) {
    ?>
    <html>
        <head>
            <link href="../semantic-ui/dist/semantic.css" rel="stylesheet"/>
            <script src="../semantic-ui/dist/semantic.js"></script>
        </head>
        <body style="margin: 0 auto;">
            <br>
            <br>
            <br>
            <div style="width: 60%; margin:  0 auto;">
                <form class="ui form" action="process/addpartprocess.php" method="POST">
                    <div class="field">
                        <label>Enter body part</label>
                        <input type="text" name="part" placeholder="Head" required="">
                    </div>
                    <div class="field">
                        <select name="gender" required="">
                            <option value="" selected="" disabled="">Gender</option>
                            <option value="1">Male</option>
                            <option value="2">Female</option>
                        </select>
                    </div>
                    <div class="field">
                        <button class="ui button">Add</button>
                    </div>
                </form>
            </div>
        </body>
    </html>

    <?php
} else {
    header("Location: index.php");
}