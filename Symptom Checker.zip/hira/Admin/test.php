<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "project";

$link = mysqli_connect($host, $user, $pass, $db) or die("Unable to connect");
$query = "SELECT * FROM sp_age WHERE '7' IN BETWEEN (min_age, max_age)";
$res = mysqli_query($link, $query);
echo 'Error: ' + mysqli_error($link) . "<br>";
var_dump($res);