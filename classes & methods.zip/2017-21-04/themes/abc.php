<!DOCTYPE html>
<html>
<head>
	<title><?php echo $title ?></title>
</head>
<body>
<div class="header">
	<?php $main->render() ?>
</div>

<div class="contents">
	<?php echo $contents ?>
</div>

<div class="footer"></div>

</body>
</html>