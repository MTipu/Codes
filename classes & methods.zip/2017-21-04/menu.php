<?php 


class Menu
{
	public $arr = [];
	public $classes = [];

	public function add($caption, $url)
	{
		$this->arr[] = [$caption, $url];
	}

	public function addClass($class)
	{
		$this->classes[] = $class;
	}

	public function render()
	{
		$class = implode(' ', $this->classes);

		if (!empty($class))
		{
			echo '<ul class="' . $class . '">' . "\r\n";
		}
		else
		{
			echo '<ul>' . "\r\n";
		}

		foreach ($this->arr as $item)
		{
			echo '	<li>' . "\r\n";
			echo '		<a href="' . $item[1] . '">' . "\r\n";
			echo '			' . $item[0] . "\r\n";
			echo '		</a>' . "\r\n";
			echo '	</li>' . "\r\n";
		}

		echo '</ul>' . "\r\n";
	}
}

// $main = new Menu();

// $main->addClass("menu");
// $main->addClass("menu-main");

// $main->add("Home", "http://www.example.com");
// $main->add("Contact Us", "http://www.example.com/contact");
// $main->add("Privacy Policy", "http://www.example.com/privacy");

// $main->render();