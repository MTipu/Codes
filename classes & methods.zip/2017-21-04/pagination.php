<?php 

class Pagination
{
	public $total;
	public $per_page;
	public $current_page;

	public function get_num_pages()
	{
		return ceil( $this->total / $this->per_page );
	}

	public function get_offset($page)
	{
		return $this->per_page * ( $page - 1);
	}

	public function loop($callback)
	{
		$total = $this->get_num_pages();

		for ($page=1; $page<=$total; $page++)
		{
			$callback($page, $page==1, $page == $total, $page == $this->current_page);
		}
	}
}


function test($page, $is_first, $is_last, $is_current)
{
	if ($is_current)
	{
		echo '<a class="active" href="http://www.example.com/students?page=' . $page . '">' . $page . '</a><br />';
	}
	else
	{
		echo '<a href="http://www.example.com/students?page=' . $page . '">' . $page . '</a><br />';
	}
}

$p = new Pagination();

$p->total = 100;
$p->per_page = 10;
$p->current_page = 3;

$p->loop('test');

