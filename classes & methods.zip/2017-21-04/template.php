<?php 

include "Menu.php";

class Template
{
	public $vars = [];

	public function setVar($var, $data)
	{
		$this->vars[$var] = $data;
	}

	public function render($theme)
	{
		extract($this->vars);

		include $theme;
	}
}

$main = new Menu();

$main->addClass("menu");
$main->addClass("menu-main");

$main->add("Home", "http://www.example.com");
$main->add("Contact Us", "http://www.example.com/contact");
$main->add("Privacy Policy", "http://www.example.com/privacy");


$t = new Template();

$t->setVar("title", "Test Page");
$t->setVar("main", $main);
$t->setVar("contents", "<h1>Welcome</h1>");

$t->render('themes/abc.php');

