<?php 

class Table
{
	public $rows = [];

	public function addRow()
	{
		$arr = func_get_args();
		$this->rows[] = $arr;
	}

	public function render()
	{
		$code = [];

		$code[] = '<table border=1>';

		foreach ($this->rows as $row)
		{
			$code[] = '	<tr>';

			foreach ($row as $value)
			{
				$code[] = '		<td>' . $value . '</td>';
			}

			$code[] = '	</tr>';
		}

		$code[] = '</table>';

		echo "\r\n" . implode("\r\n", $code) . "\r\n";
	}
}

// $t = new Table();

// $t->addRow("A", "B", "C");
// $t->addRow("1", "2", "3");
// $t->addRow("i", "ii", "iii");

// $t->render();



// $t = new Table();

// $t->addRow("A", "B", "C", "D", "E");
// $t->addRow("1", "2", "3", "4", "5");
// $t->addRow("i", "ii", "iii", "iv", "v");

// $t->render();


$t = new Table();

$t->addRow("Name", '<input  value="123" />');
$t->addRow("Gender", "<select><option>--- Select Gender ---</option><option>Male</option><option>Female</option></select>");

$t->render();