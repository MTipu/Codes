<pre><?php

########################################################################################################################
#Insertion,Updation,Deletion Through Classes Or Methods
########################################################################################################################
	
class Student
{
	public $id;
	public $name;
	public $age;
	public $gender;

	public function insert()
	{
		$id = mysql_real_escape_string($this->id);
		$name = mysql_real_escape_string($this->name);
		$age = mysql_real_escape_string($this->age);
		$gender = mysql_real_escape_string($this->gender);

		if (empty($id))
		{
			$id = 'NULL';
		}
		else
		{
			$id = "'" . $id . "'";
		}

		$sql = 'INSERT INTO `Student` (`id`, `name`, `age`, `gender`) VALUES (' . $id . ', "' . $name . '", "' . $age . '", "' . $gender . '")';

		mysql_query($sql) or die(mysql_error());
	}

	public function update()
	{
		$id = mysql_real_escape_string($this->id);
		$name = mysql_real_escape_string($this->name);
		$age = mysql_real_escape_string($this->age);
		$gender = mysql_real_escape_string($this->gender);

		if (empty($id))
		{
			return;
		}

		$sql = 'UPDATE `Student` SET `name`="' . $name . '", `age`="' . $age . '", `gender`= "' . $gender . '" WHERE `id`=' . $id;

		mysql_query($sql) or die(mysql_error());
	}

	public function delete()
	{
		$id = mysql_real_escape_string($this->id);

		if (empty($id))
		{
			return;
		}

		$sql = 'DELETE FROM `Student` WHERE `id`=' . $id;

		mysql_query($sql) or die(mysql_error());
	}

	public function load($id)
	{
		$id = mysql_real_escape_string($id);

		if (empty($id))
		{
			return;
		}

		$sql = 'SELECT * FROM `Student` WHERE `id`=' . $id;

		$rsa = mysql_query($sql);

		$row = mysql_fetch_assoc($rsa);

		$this->id = $row['id'];
		$this->name = $row['name'];
		$this->age = $row['age'];
		$this->gender = $row['gender'];
	}

	public static function find($id=null)
	{
		if ( !is_null($id) )
		{
			$student = new Student();
			$student->load($id);
			return $student;
		}

		$sql = 'SELECT * FROM `Student`';

		$rsa = mysql_query($sql);

		$arr = [];

		while ($row = mysql_fetch_assoc($rsa))
		{
			$student = new Student();
			$student->id = $row['id'];
			$student->age = $row['age'];
			$student->name = $row['name'];
			$student->gender = $row['gender'];

			$arr[] = $student;
		}

		return $arr;
	}

	public function debug()
	{
		echo "Student [ id: " . $this->id . ", Name: " . $this->name . ", Age: " . $this->age . ", Gender: " . $this->gender . " ]<br/>";
	}
}


@mysql_connect("localhost", "root", "123456");
@mysql_select_db("student");


// $student = new Student();
// $student->name = 'Bilal';
// $student->age = '90';
// $student->gender = 'Male';

// $student = new Student();
// $student->id = '1';
// $student->name = 'Rida';
// $student->age = '15';
// $student->gender = 'Female';
// $student->update();


// $student = new Student();
// $student->load(1);

// $s = Student::find(3);
// $s->debug();


foreach (Student::find() as $student)
{
	$student->debug();
}



// echo '<br />';
// $s->update();


// class Student
// {
// 	public $id;
// 	public $name;
// 	public $gender;

// 	public function save()
// 	{
// 		$this->id
// 		$this->name
// 		$this->gender
// 	}

// 	public function circum()
// 	{
// 		return ($this->width + $this->height) * 2;
// 	}

// 	public function debug()
// 	{
// 		echo "Width: " . $this->width . ", Height: " . $this->height . ", Area: " . $this->area() . ", Circum: " . $this->circum();
// 	}
// }


// $s = new Student();

// $s->name = $GET['id'];
// $s->gender = 'Male';

// $s->create();
