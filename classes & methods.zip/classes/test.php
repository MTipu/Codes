<pre><?php


class Student
{
	public $name;
	public $age;
	public $gender;

	public static function create($name, $age, $gender)
	{
		$student = new Student();

		$student->name = $name;
		$student->age = $age;
		$student->gender = $gender;

		return $student;
	}
}


$arr = [
			Student::create("Ali", 20, 'male'),
			Student::create("Rida", 25, 'female')
		];


print_r($arr);
