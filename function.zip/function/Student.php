<?php

include "db.php";
include "db_student.php";

db_connect();

$form_row = ['id' => '', 'name' => '', 'age' => ''];


if ( array_key_exists('action', $_GET) && $_GET['action'] == 'edit')
{
	if (!empty($_POST))
	{
		db_student_update($_GET['id'], $_POST['name'], $_POST['age']);
		header('Location: http://localhost/First/Student.php');
	}

	$form_row = db_student_by_id($_GET['id']);
}

if ( array_key_exists('action', $_GET) && $_GET['action'] == 'delete')
{
	db_student_delete($_GET['id']);
	header('Location: http://localhost/First/Student.php');
}

if (!empty($_POST) && !array_key_exists('action', $_GET))
{
	db_student_insert($_POST['id'], $_POST['name'], $_POST['age']);
	header('Location: http://localhost/First/Student.php');
}

?><!DOCTYPE html>
<html>
<head>
	<title>My First Page</title>
<style>

body {
     background-color: #C0C0C0;
    text-align: center;

}

</style>

</head>
<body>

<form action="" method="post" >
<br />
<table align="center">
	<tr>
		<td>Id</td>
		<td><input type="text" name="id" value="<?php echo $form_row['id']; ?>" /></td>
	</tr>

	<tr>
		<td>Name</td>
		<td><input type="text" name="name" value="<?php echo $form_row['name']; ?>" /></td>
	</tr>

	<tr>
		<td>Age</td>
		<td><input type="text" name="age" value="<?php echo $form_row['age']; ?>" /></td>
	</tr>

	<tr>
		<td></td>
		<td><input type="submit" value="<?php echo empty($form_row['id']) ? 'Add':'Update'; ?>" /></td>
	</tr>

</table>

<br /> <br />
<table border = "1" width="500" align = "center" >
	<tr>
		<th>Id</td>
		<th>Name</td>
		<th>Age</td>
		<th>Actions</td>
	</tr>
<?php foreach (db_student_all() as $student)
{
	echo '	<tr>' . "\r\n";
	echo '		<td>' . $student['id'] . '</td>' . "\r\n";
	echo '		<td>' . $student['name'] . '</td>' . "\r\n";
	echo '		<td>' . $student['age'] . '</td>' . "\r\n";
	echo '		<td><a href="?action=edit&id=' . $student['id'] .  '"  >  Edit</a> <a href="?action=delete&id=' . $student['id'] . '">Delete</a></td>' . "\r\n";
	echo '	</tr>' . "\r\n";

}
?>
</table>

</body>
</html>
