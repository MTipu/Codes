<?php

// include "db.php";
// db_connect();

function db_student_insert($id, $name, $age)
{
	$id = mysql_real_escape_string($id);
	$name = mysql_real_escape_string($name);
	$age = mysql_real_escape_string($age);

	if (empty($id))
	{
		$id = 'NULL';
	}
	else
	{
		$id = '"' . $id . '"';
	}

	$sql = 'INSERT INTO `student` (`id`, `name`, `age`) VALUES (' . $id . ',"' . $name . '","' . $age . '")';

	mysql_query($sql) or die(mysql_error());
}

function db_student_update($id, $name, $age)
{
	$id = mysql_real_escape_string($id);
	$name = mysql_real_escape_string($name);
	$age = mysql_real_escape_string($age);

	if (empty($id))
	{
		$id = 'NULL';
	}
	else
	{
		$id = '"' . $id . '"';
	}

	$sql = 'UPDATE `student` set `name`="' . $name . '", `age`="' . $age . '" WHERE `id`=' . $id;

	mysql_query($sql) or die(mysql_error());
}

function db_student_delete($id)
{
	$id = mysql_real_escape_string($id);
	$sql = 'DELETE FROM `student` WHERE `id`=' . $id;

	mysql_query($sql) or die(mysql_error());
}

function db_student_all($key = null)
{
	$sql = 'SELECT * FROM `student`';
	$rsa = mysql_query($sql);

	$arr = [];

	while ($row = mysql_fetch_assoc($rsa))
	{
		if ($key == null)
		{
			$arr[] = $row;
		}
		else
		{
			if (array_key_exists($key, $row))
			{
				$arr[$row[$key]] = $row;
			}
			else
			{
				$arr[] = $row;
			}
		}
	}

	return $arr;
}


function db_student_by_id($id)
{
	$id = mysql_real_escape_string($id);
	$sql = 'SELECT * FROM `student` WHERE `id`="' . $id . '"';
	$rsa = mysql_query($sql);

	while ($row = mysql_fetch_assoc($rsa))
	{
		return $row;
	}

	return false;

}


